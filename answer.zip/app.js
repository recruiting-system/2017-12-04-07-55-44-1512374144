const main = require('./main/main');

main();